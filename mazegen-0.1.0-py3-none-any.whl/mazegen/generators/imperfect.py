import random
from typing import Generator

from . import BaseGenerator
from ..utils import Direction


class ImperfectGenerator(BaseGenerator):

    def __init__(self, base_generator: BaseGenerator) -> None:
        super().__init__(base_generator.maze)
        self.base_generator = base_generator

    def _algorithm_loop(self) \
            -> Generator[tuple[int, int, Direction], None, None]:
        """Remove walls from eligible dead-end cells.

        Scans the maze in row-major order. For each unlocked cell with
        exactly three walls, removes a randomly selected wall to an eligible
        neighboring cell, if one exists. The maze grid is modified in place.
        Random choices are initialized using the maze seed.
        """

        while (base_step := self.base_generator.step()) is not None:
            yield base_step

        yield from self.make_imperfect()

    def generate_all(self) -> None:
        for _ in self.make_imperfect():
            pass

    @staticmethod
    def _count_walls(cell_pos: int,
                     walls: tuple[int, int, int, int]) -> int:
        return sum(bool(wall & cell_pos) for wall in walls)

    def _creates_3x3_room(self, x: int, y: int, nx: int, ny: int) -> bool:
        """Return True if opening between x,y / nx,ny creates a 3x3 room."""
        width = self.maze.width
        height = self.maze.height
        if width < 3 or height < 3:
            return False

        _, we, ws, _ = self.maze.get_walls()
        idx_a = y * width + x
        idx_b = ny * width + nx

        if y == ny:
            we &= ~(1 << min(idx_a, idx_b))
        else:
            ws &= ~(1 << min(idx_a, idx_b))

        min_x = max(0, min(x, nx) - 2)
        max_x = min(width - 3, max(x, nx))
        min_y = max(0, min(y, ny) - 2)
        max_y = min(height - 3, max(y, ny))

        for top_y in range(min_y, max_y + 1):
            for left_x in range(min_x, max_x + 1):
                v_closed = any(
                    we & (1 << ((top_y + dy) * width + (left_x + dx)))
                    for dy in range(3)
                    for dx in range(2)
                )
                if v_closed:
                    continue

                h_closed = any(
                    ws & (1 << ((top_y + dy) * width + (left_x + dx)))
                    for dy in range(2)
                    for dx in range(3)
                )
                if not h_closed:
                    return True

        return False

    def _count_safe_moves(
            self, x: int, y: int, locked: set[tuple[int, int]]
    ) -> int:
        wn, we, ws, ww = self.maze.get_walls()
        cell_pos = 1 << ((y * self.maze.width) + x)
        moves = [
            (x, y - 1, bool(wn & cell_pos)),
            (x + 1, y, bool(we & cell_pos)),
            (x, y + 1, bool(ws & cell_pos)),
            (x - 1, y, bool(ww & cell_pos)),
        ]
        return sum(
            1
            for nx, ny, closed in moves
            if closed
            and 0 <= nx < self.maze.width
            and 0 <= ny < self.maze.height
            and (nx, ny) not in locked
            and not self._creates_3x3_room(x, y, nx, ny)
        )

    def make_imperfect(self) \
            -> Generator[tuple[int, int, Direction], None, None]:
        """Remove walls from eligible dead-end cells.

        Scans the maze in row-major order. For each unlocked cell with
        exactly three walls, removes a randomly selected wall to an eligible
        neighboring cell, if one exists. The maze grid is modified in place.
        Random choices are initialized using the maze seed.
        """
        if self.maze.perfect:
            return

        if self.maze.seed is not None:
            random.seed(self.maze.seed)

        blind_ends: list[tuple[int, int]] = []
        locked = set(self.maze.locked_cells)
        width = self.maze.width
        height = self.maze.height

        walls = self.maze.get_walls()
        for y in range(height):
            for x in range(width):
                if (x, y) not in locked:
                    cell_pos = 1 << ((y * width) + x)
                    if self._count_walls(cell_pos, walls) == 3:
                        blind_ends.append((x, y))

        random.shuffle(blind_ends)
        blind_ends.sort(
            key=lambda pos: self._count_safe_moves(pos[0], pos[1], locked),
            reverse=True,
        )

        while blind_ends:
            x, y = blind_ends.pop()
            cell_pos = 1 << ((y * width) + x)
            wn, we, ws, ww = self.maze.get_walls()
            if self._count_walls(cell_pos, (wn, we, ws, ww)) == 3:
                candidates = []

                if ((wn & cell_pos) and y > 0
                        and (x, y - 1) not in locked):
                    candidates.append((x, y - 1))
                if ((we & cell_pos) and x < width - 1
                        and (x + 1, y) not in locked):
                    candidates.append((x + 1, y))
                if ((ws & cell_pos) and y < height - 1
                        and (x, y + 1) not in locked):
                    candidates.append((x, y + 1))
                if ((ww & cell_pos) and x > 0
                        and (x - 1, y) not in locked):
                    candidates.append((x - 1, y))

                safe_candidates = [
                    (cx, cy) for cx, cy in candidates
                    if not self._creates_3x3_room(x, y, cx, cy)
                ]

                if safe_candidates:
                    nx, ny = random.choice(safe_candidates)

                    cell_a_idx = (y * width) + x
                    cell_b_idx = (ny * width) + nx

                    self.maze.flip_both_walls(cell_a_idx, cell_b_idx)
                    yield self.maze.get_coords_and_dir(cell_a_idx, cell_b_idx)
